Diagnostic package. source.png preserves the original decoded pixels, without overlays.
report.json contains detection-time settings and the currently reviewed cuts.
reference.png is the exact reference selected for this run (whether matched or rejected).
